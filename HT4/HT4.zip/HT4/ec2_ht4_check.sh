#!/bin/bash
set -euo pipefail

if [ "${1:-}" = "" ]; then
  echo "Usage: $0 <ip-or-url> [expected-student-id]"
  exit 2
fi

TARGET="$1"
EXPECTED_STUDENT="${2:-}"
MARKER="EC2-HT4-OK"

if [[ "$TARGET" =~ ^https?:// ]]; then
  BASE_URL="${TARGET%/}"
else
  BASE_URL="http://$TARGET"
fi

TMP_DIR="$(mktemp -d)"
INDEX_FILE="$TMP_DIR/index.html"
JSON_FILE="$TMP_DIR/check.json"
cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

PASS_COUNT=0
FAIL_COUNT=0

pass() {
  echo "OK   - $1"
  PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
  echo "FAIL - $1"
  FAIL_COUNT=$((FAIL_COUNT + 1))
}

fetch() {
  local url="$1"
  local output="$2"
  local status
  status="$(curl -fsS -m 10 -o "$output" -w "%{http_code}" "$url" 2>/dev/null || true)"
  echo "$status"
}

INDEX_STATUS="$(fetch "$BASE_URL/" "$INDEX_FILE")"
if [ "$INDEX_STATUS" = "200" ]; then
  pass "GET / returned HTTP 200"
else
  fail "GET / returned HTTP ${INDEX_STATUS:-error}"
fi

JSON_STATUS="$(fetch "$BASE_URL/check.json" "$JSON_FILE")"
if [ "$JSON_STATUS" = "200" ]; then
  pass "GET /check.json returned HTTP 200"
else
  fail "GET /check.json returned HTTP ${JSON_STATUS:-error}"
fi

if [ -s "$INDEX_FILE" ] && grep -q "$MARKER" "$INDEX_FILE"; then
  pass "Main page contains marker $MARKER"
else
  fail "Main page does not contain marker $MARKER"
fi

if [ -n "$EXPECTED_STUDENT" ]; then
  if [ -s "$INDEX_FILE" ] && grep -q "$EXPECTED_STUDENT" "$INDEX_FILE"; then
    pass "Main page contains expected student identifier"
  else
    fail "Main page does not contain expected student identifier"
  fi
fi

if python3 -m json.tool "$JSON_FILE" >/dev/null 2>&1; then
  pass "/check.json is valid JSON"
else
  fail "/check.json is not valid JSON"
fi

read_json_field() {
  local expr="$1"
  python3 - "$JSON_FILE" "$expr" <<'PY'
import json
import sys

path = sys.argv[1]
expr = sys.argv[2].split(".")
with open(path, "r", encoding="utf-8") as fh:
    data = json.load(fh)
value = data
for key in expr:
    value = value[key]
if isinstance(value, bool):
    print("true" if value else "false")
else:
    print(value)
PY
}

check_field_equals() {
  local field="$1"
  local expected="$2"
  local actual=""
  if actual="$(read_json_field "$field" 2>/dev/null)"; then
    if [ "$actual" = "$expected" ]; then
      pass "JSON field $field == $expected"
    else
      fail "JSON field $field expected $expected but got $actual"
    fi
  else
    fail "JSON field $field is missing"
  fi
}

check_field_nonempty() {
  local field="$1"
  local actual=""
  if actual="$(read_json_field "$field" 2>/dev/null)" && [ -n "$actual" ]; then
    pass "JSON field $field is present"
  else
    fail "JSON field $field is missing or empty"
  fi
}

check_field_equals "task" "HT4"
check_field_equals "marker" "$MARKER"
check_field_nonempty "student"
check_field_nonempty "hostname"
check_field_nonempty "updated_at_utc"
check_field_nonempty "network.vpc_id"
check_field_nonempty "network.vpc_cidr"
check_field_nonempty "network.subnet_id"
check_field_nonempty "network.subnet_cidr"
check_field_nonempty "network.availability_zone"
check_field_equals "network.public_subnet_count" "2"
check_field_equals "network.private_subnet_count" "2"
check_field_equals "network.total_subnet_count" "4"
check_field_equals "iam.instance_profile_attached" "true"
check_field_equals "checks.nginx_active" "true"
check_field_equals "checks.nginx_enabled" "true"
check_field_equals "checks.devops_user_exists" "true"
check_field_equals "checks.imdsv2_used" "true"
check_field_equals "checks.custom_vpc_used" "true"
check_field_equals "checks.public_subnet_count_ok" "true"
check_field_equals "checks.private_subnet_count_ok" "true"
check_field_equals "checks.private_subnets_without_igw_default_route" "true"

if [ -n "$EXPECTED_STUDENT" ]; then
  check_field_equals "student" "$EXPECTED_STUDENT"
fi

echo
echo "Summary: $PASS_COUNT passed, $FAIL_COUNT failed"

if [ "$FAIL_COUNT" -eq 0 ]; then
  exit 0
fi

exit 1
