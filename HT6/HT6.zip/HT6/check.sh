#!/usr/bin/env bash
# =============================================================================
# check.sh — HT6 verification script
# Usage:  ./check.sh <PUBLIC_IP> [--swarm]
#
# Checks Parts 1-3 by default (Compose stack must be running on port 80).
# Pass --swarm to also check Part 4 (service must be running on port 5000).
# =============================================================================

set -euo pipefail

IP="${1:-}"
CHECK_SWARM=false

if [[ -z "$IP" ]]; then
  echo "Usage: $0 <PUBLIC_IP> [--swarm]"
  exit 1
fi

if [[ "${2:-}" == "--swarm" ]]; then
  CHECK_SWARM=true
fi

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

PASS=0; FAIL=0; SKIP=0

pass()   { echo -e "  ${GREEN}✔${NC} $1"; ((PASS++));  }
fail()   { echo -e "  ${RED}✘${NC} $1"; ((FAIL++));   }
skip()   { echo -e "  ${YELLOW}~${NC} $1"; ((SKIP++)); }
header() { echo -e "\n${CYAN}${BOLD}▶ $1${NC}"; }

http_get() {
  local url="$1"
  local timeout="${2:-5}"
  curl -s -o /tmp/ht6_body -w "%{http_code}" --max-time "$timeout" "$url" 2>/dev/null || echo "000"
}

body() { cat /tmp/ht6_body 2>/dev/null || true; }

echo -e "\n${BOLD}════════════════════════════════════════${NC}"
echo -e "${BOLD}  HT6 Check  │  Target: ${IP}${NC}"
echo -e "${BOLD}════════════════════════════════════════${NC}"

# ── Part 1+3 — Compose stack ──────────────────────────────────────────────────
header "Part 1+3 — Compose stack (port 80)"

code=$(http_get "http://${IP}/")
if [[ "$code" == "200" ]]; then
  resp=$(body)
  if echo "$resp" | grep -qi "hello from flask"; then
    pass "Port 80 reachable — Flask response via Nginx"
  else
    fail "Port 80 returned 200 but unexpected body: $(echo "$resp" | head -1 | tr -d '\r\n')"
  fi
else
  fail "Port 80 not reachable (HTTP $code). Is 'docker compose up' running?"
fi

# ── Part 3 — Health endpoint ──────────────────────────────────────────────────
header "Part 3 — Health endpoint"

code=$(http_get "http://${IP}/health")
if [[ "$code" == "200" ]]; then
  resp=$(body)
  if echo "$resp" | grep -q '"status".*"ok"\|"status":"ok"'; then
    version=$(echo "$resp" | grep -o '"version":"[^"]*"\|"version": "[^"]*"' | head -1 | grep -o '"[^"]*"$' | tr -d '"')
    pass "/health OK — app version: ${version:-unknown}"
  else
    fail "/health returned 200 but missing status:ok — body: $(echo "$resp" | head -1)"
  fi
else
  fail "/health returned HTTP $code (expected 200)"
fi

# ── Part 2 — Buildx secret isolation ─────────────────────────────────────────
header "Part 2 — Buildx secret isolation"

code=$(http_get "http://${IP}/secret-check")
if [[ "$code" == "200" ]]; then
  resp=$(body)
  if echo "$resp" | grep -q '"leaked".*false\|"leaked": *false'; then
    pass "Secret NOT present at runtime — buildx --mount=type=secret worked"
  elif echo "$resp" | grep -q '"leaked".*true'; then
    fail "Secret IS present in the running container — secret was baked into the image layer"
  else
    fail "Unexpected /secret-check response: $(echo "$resp" | head -1)"
  fi
elif [[ "$code" == "404" ]]; then
  fail "/secret-check not found — did you build with 'flask-app:secure' and deploy that image?"
elif [[ "$code" == "000" ]]; then
  fail "Could not reach /secret-check (connection refused or timeout)"
else
  fail "/secret-check returned HTTP $code"
fi

# ── Part 3 — Nginx as reverse proxy ──────────────────────────────────────────
header "Part 3 — Nginx reverse proxy"

nginx_header=$(curl -s -I --max-time 5 "http://${IP}/" 2>/dev/null | grep -i "^server:" || true)
if echo "$nginx_header" | grep -qi "nginx"; then
  pass "Nginx confirmed as reverse proxy"
else
  skip "Could not confirm Nginx via Server header (header may be stripped by nginx config)"
fi

# ── Part 4 — Swarm service (optional) ────────────────────────────────────────
header "Part 4 — Docker Swarm service (bonus)"

if $CHECK_SWARM; then
  code=$(http_get "http://${IP}:5000/health" 8)
  if [[ "$code" == "200" ]]; then
    resp=$(body)
    if echo "$resp" | grep -q '"status".*"ok"\|"status":"ok"'; then
      version=$(echo "$resp" | grep -o '"version":"[^"]*"\|"version": "[^"]*"' | head -1 | grep -o '"[^"]*"$' | tr -d '"')
      pass "Swarm service reachable on port 5000 — version: ${version:-unknown}"
    else
      fail "Port 5000 responded but /health body unexpected: $(echo "$resp" | head -1)"
    fi
  else
    fail "Port 5000 not reachable (HTTP $code). Is 'docker service create --publish 5000:5000' running?"
  fi
else
  skip "Swarm checks skipped — re-run with --swarm while the service is up on port 5000"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo -e "\n${BOLD}════════════════════════════════════════${NC}"
echo -e "${BOLD}  Results: ${GREEN}${PASS} passed${NC}  ${RED}${FAIL} failed${NC}  ${YELLOW}${SKIP} skipped${NC}"
echo -e "${BOLD}════════════════════════════════════════${NC}\n"

if [[ $FAIL -gt 0 ]]; then
  exit 1
fi
