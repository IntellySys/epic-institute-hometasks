#!/bin/bash
set -euo pipefail

if [ "${1:-}" = "" ]; then
  echo "Usage: $0 <ip-or-url> [expected-student-id]"
  exit 2
fi

TARGET="$1"
EXPECTED_STUDENT="${2:-}"
MARKER="EC2-HT5-OK"

if [[ "$TARGET" =~ ^https?:// ]]; then
  TARGET="${TARGET#http://}"
  TARGET="${TARGET#https://}"
fi

TARGET="${TARGET%/}"
HTTP_URL="http://$TARGET"
HTTPS_URL=""

TMP_DIR="$(mktemp -d)"
INDEX_FILE="$TMP_DIR/index.html"
JSON_FILE="$TMP_DIR/check.json"
HEADERS_FILE="$TMP_DIR/headers.txt"
cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

PASS_COUNT=0
FAIL_COUNT=0

pass() {
  echo "OK   - $1"
  PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
  echo "FAIL - $1"
  FAIL_COUNT=$((FAIL_COUNT + 1))
}

HTTP_STATUS="$(curl -sS -I -m 10 -D "$HEADERS_FILE" -o /dev/null "$HTTP_URL/" -w "%{http_code}" 2>/dev/null || true)"
if [[ "$HTTP_STATUS" =~ ^30[1278]$ ]]; then
  pass "GET / over HTTP returned redirect status $HTTP_STATUS"
else
  fail "GET / over HTTP returned status ${HTTP_STATUS:-error}"
fi

if grep -Eiq '^Location: https://' "$HEADERS_FILE"; then
  pass "HTTP redirect points to HTTPS"
  HTTPS_URL="$(awk 'BEGIN{IGNORECASE=1} /^Location: https:\/\// {gsub(/\r/, "", $2); print $2; exit}' "$HEADERS_FILE")"
else
  fail "HTTP redirect does not point to HTTPS"
fi

if [ -z "$HTTPS_URL" ]; then
  HTTPS_URL="https://$TARGET"
fi

HTTPS_STATUS="$(curl -kfsS -m 10 -o "$INDEX_FILE" -w "%{http_code}" "$HTTPS_URL" 2>/dev/null || true)"
if [ "$HTTPS_STATUS" = "200" ]; then
  pass "GET / over HTTPS returned HTTP 200"
else
  fail "GET / over HTTPS returned HTTP ${HTTPS_STATUS:-error}"
fi

JSON_BASE_URL="${HTTPS_URL%/}"
JSON_STATUS="$(curl -kfsS -m 10 -o "$JSON_FILE" -w "%{http_code}" "$JSON_BASE_URL/check.json" 2>/dev/null || true)"
if [ "$JSON_STATUS" = "200" ]; then
  pass "GET /check.json over HTTPS returned HTTP 200"
else
  fail "GET /check.json over HTTPS returned HTTP ${JSON_STATUS:-error}"
fi

if [ -s "$INDEX_FILE" ] && grep -q "$MARKER" "$INDEX_FILE"; then
  pass "HTTPS page contains marker $MARKER"
else
  fail "HTTPS page does not contain marker $MARKER"
fi

if [ -n "$EXPECTED_STUDENT" ]; then
  if [ -s "$INDEX_FILE" ] && grep -q "$EXPECTED_STUDENT" "$INDEX_FILE"; then
    pass "HTTPS page contains expected student identifier"
  else
    fail "HTTPS page does not contain expected student identifier"
  fi
fi

if python3 -m json.tool "$JSON_FILE" >/dev/null 2>&1; then
  pass "/check.json is valid JSON"
else
  fail "/check.json is not valid JSON"
fi

read_json_field() {
  local expr="$1"
  python3 - "$JSON_FILE" "$expr" <<'PY'
import json
import sys

path = sys.argv[1]
expr = sys.argv[2].split(".")
with open(path, "r", encoding="utf-8") as fh:
    data = json.load(fh)
value = data
for key in expr:
    value = value[key]
if isinstance(value, bool):
    print("true" if value else "false")
else:
    print(value)
PY
}

check_field_equals() {
  local field="$1"
  local expected="$2"
  local actual=""
  if actual="$(read_json_field "$field" 2>/dev/null)"; then
    if [ "$actual" = "$expected" ]; then
      pass "JSON field $field == $expected"
    else
      fail "JSON field $field expected $expected but got $actual"
    fi
  else
    fail "JSON field $field is missing"
  fi
}

check_field_nonempty() {
  local field="$1"
  local actual=""
  if actual="$(read_json_field "$field" 2>/dev/null)" && [ -n "$actual" ]; then
    pass "JSON field $field is present"
  else
    fail "JSON field $field is missing or empty"
  fi
}

check_field_equals "task" "HT5"
check_field_equals "marker" "$MARKER"
check_field_nonempty "student"
check_field_nonempty "updated_at_utc"
check_field_equals "docker.installed" "true"
check_field_equals "docker.container_running" "true"
check_field_equals "docker.image_built_from_ubuntu" "true"
check_field_equals "web.https_enabled" "true"
check_field_equals "web.http_redirect_to_https" "true"
check_field_equals "checks.nginx_running_in_container" "true"
check_field_equals "checks.custom_index_present" "true"
check_field_equals "checks.check_json_present" "true"

if [ -n "$EXPECTED_STUDENT" ]; then
  check_field_equals "student" "$EXPECTED_STUDENT"
fi

echo
echo "Summary: $PASS_COUNT passed, $FAIL_COUNT failed"

if [ "$FAIL_COUNT" -eq 0 ]; then
  exit 0
fi

exit 1
